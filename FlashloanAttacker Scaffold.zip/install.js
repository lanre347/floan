const fs = require("fs-extra");
const path = require("path");

// Step 1: Read the current directory
fs.readdir(".", (err, files) => {
  if (err) throw err;

  // Step 2: Filter out 'cookbook' and pick the first directory that is not 'cookbook'
  const targetDir = files.find((file) => file !== "node_modules" && file !== "contracts" && fs.lstatSync(file).isDirectory());

  // Step 3: Read all directories and files in the current directory
  fs.readdir(".", (err, allFiles) => {
    if (err) throw err;

    // Step 4: Filter out the picked directory
    let filesToMove = allFiles.filter((file) => {
      if (file === "hardhat.config.ts" || file === "contracts") {
        return true;
      } else return false;
    });

    // Step 5: Move all remaining directories and files into the picked directory under '/packages/hardhat'
    for (file of filesToMove) {
      const oldPath = path.join(".", file);
      const newPath = path.join(".", targetDir, "packages", "hardhat", file);
      fs.moveSync(oldPath, newPath, { overwrite: true }, (err) => {
        if (err) throw err;
      });
    }

    let filesToDelete = allFiles.filter((file) => {
      if (file === targetDir || file === "hardhat.config.ts" || file === "contracts") {
        return false;
      } else return true;
    });
    filesToDelete.forEach((file) => {
      fs.rm(file, { recursive: true });
    });
  });
});
