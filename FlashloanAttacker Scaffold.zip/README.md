# Cookbook.dev

## Find any smart contract, build your project faster

Get ready-to-use Hardhat projects directly from https://www.cookbook.dev/?utm=code

## Please follow these 4 steps for a local deploy

### Step 1: Install ScaffoldETH 2

Run "yarn scaffold " to install scaffold and copy contract contents.

### Step 2: Pick Hardhat

When prompted to pick a framework, select Hardhat

### Step 3: Compile

Navigate to /packages/hardhat and run "yarn compile"

### Step 4: Deploy

Navigate to /packages/hardhat/deploy/00_deploy_your_contract.ts 

Edit the contract name and the constructor arguments to match the contract you want to deploy

Edit the contract function you want to call in the deploy script

Run "yarn chain"

Open a new terminal and run "yarn deploy"

### You're all set!

